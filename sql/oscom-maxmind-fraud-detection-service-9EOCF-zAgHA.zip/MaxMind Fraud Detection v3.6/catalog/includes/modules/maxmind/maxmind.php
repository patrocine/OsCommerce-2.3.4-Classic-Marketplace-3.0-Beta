<?php
/*
  maxmind.php, v3.6, 29 March 2015
  Under GNU license and developed by
  Noel "Splinter" Latsha, CISSP, ISO 27001, CEH, CIW Professional, CIW Database Design, CIW Site Design, SCJA, CWSP, E|DRP, E|CHFI, E|CEH, Project+, Network+, Security+, MCP

**  All links will be kept original **
	**  All links will be kept original **
		**  All links will be kept original **
			**  All links will be kept original **
				**  All links will be kept original **
*/
// A couple of countries have to ruin it for everyone...

// Make modifications here:

// Enter your license key here (https://www.maxmind.com/app/my_license_key?rId=nabcom)
$h["license_key"] = "XXXXXXXXXXXX";

// Request type is used if you have multiple plans in one account and wish to select type of
// query you want to make. By default the service uses the highest level available.
// modify the following line if you wish to use only standard queries with your maxmind account

$requested_type = "premium";
//$requested_type = "standard";

//uncomment to turn on debugging
// $ccfs->debug = 1;

// *************************************DO NOT MODIFY BELOW THIS LINE **********************************

//For Future Use
$txn_type = "creditcard";

$check_country_query = tep_db_query("select countries_iso_code_2 from " . TABLE_COUNTRIES . " where countries_name = '" . tep_db_input($sql_data_array['customers_country']) . "'");
$check_country = tep_db_fetch_array($check_country_query);

$check_delivery_country_query = tep_db_query("select countries_iso_code_2 from " . TABLE_COUNTRIES . " where countries_name = '" . tep_db_input($sql_data_array['delivery_country']) . "'");
$check_delivery_country = tep_db_fetch_array($check_delivery_country_query);

$check_state_query = tep_db_query("select zone_code from " . TABLE_ZONES . " where zone_name = '" . tep_db_input($sql_data_array['customers_state']) . "'");
$check_state = tep_db_fetch_array($check_state_query);

$check_delivery_state_query = tep_db_query("select zone_code from " . TABLE_ZONES . " where zone_name = '" . tep_db_input($sql_data_array['delivery_state']) . "'");
$check_delivery_state = tep_db_fetch_array($check_delivery_state_query);

$check_customer_information_query = tep_db_query("select customers_password from " . TABLE_CUSTOMERS . " where customers_id = '" . tep_db_input($sql_data_array['customers_id']) . "'");
$check_customer_information = tep_db_fetch_array($check_customer_information_query);

require(DIR_WS_MODULES . 'maxmind/CreditCardFraudDetection.php');
$ccfs = new CreditCardFraudDetection;

//Modify a few variables to match what MaxMind is expecting.


if (tep_not_null($sql_data_array['cc_number']))
	$string = $sql_data_array['cc_number'];
else if (tep_not_null($HTTP_POST_VARS['cc_number_nh-dns']))
	$string = $HTTP_POST_VARS['cc_number_nh-dns'];
else if (tep_not_null($HTTP_POST_VARS['cc_number_nh-dns']))
	$string = $confirmation['cc_card_number'];
$cc = substr($string, 0, 6);

//Email address split
$str = $sql_data_array['customers_email_address'];
list ($addy, $domain) = preg_split ('[@]', $str);
$email_address = strtolower($str);
$email_MD5 = md5($email_address);

$ip = $_SERVER['REMOTE_ADDR'];

//Set inputs and store them in a hash

$h["bin"] = $cc;
$h["city"] = $sql_data_array['customers_city'];
$h["country"] = $check_country['countries_iso_code_2'];
$h["custPhone"] = $sql_data_array['customers_telephone'];
$h["domain"] = $domain;
$h["emailMD5"] = $email_MD5;
$h["i"] = $ip;
// $h["order_amount"] = $order_amount;  //Future Use
$h["order_currency"] = $sql_data_array['currency'];
$h["passwordMD5"] = $check_customer_information['customers_password'];
$h["postal"] = $sql_data_array['customers_postcode'];
$h["region"] = $check_state['zone_code'];
$h["sessionID"] = session_id();
$h["shipAddr"] = $sql_data_array['delivery_street_address'];
$h["shipCity"] = $sql_data_array['delivery_city'];
$h["shipCountry"] = $check_delivery_country['countries_iso_code_2'];
$h["shipPostal"] = $sql_data_array['delivery_postcode'];
$h["shipRegion"] = $check_delivery_state['zone_code'];
$h["txn_type"] = $txn_type;
$h["txnID"] = $insert_id;
$h['accept_language'] = getenv("HTTP_ACCEPT_LANGUAGE");
$h['forwardedIP'] = getenv("HTTP_X_FORWARDED_FOR");
$h['requested_type'] = $request_type;
$h['user_agent'] = getenv("HTTP_USER_AGENT");
$h['usernameMD5'] = $email_MD5;

// Store Passed parameters for later viewing.
$sql_data_array = array('order_id' => $insert_id,
							'accept_language' => $h["accept_language"],
							'bin' => $h["bin"],
							'city' => $h["city"],
							'country' => $h["country"],
							'custPhone' => $h["custPhone"],
							'domain' => $h["domain"],
							'emailMD5' => $h["emailMD5"],
							'forwardedIP' => $h["forwardedIP"],
							'ip_address' => $h["i"],
							'license_key' => $h["license_key"],
							'order_amount' => $h["order_amount"],
							'order_currency' => $h["order_currency"],
							'passwordMD5' => $h["passwordMD5"],
							'postal' => $h["postal"],
							'region' => $h["region"],
							'requested_type' => $h["requested_type"],
							'sessionID' => $h["sessionID"],
							'shipAddr' => $h["shipAddr"],
							'shipCity' => $h["shipCity"],
							'shipCountry' => $h["shipCountry"],
							'shipPostal' => $h["shipPostal"],
							'shipRegion' => $h["shipRegion"],
							'txnID' => $h["txnID"],
							'txn_type' => $h["txn_type"],
							'usernameMD5' => $h["usernameMD5"],
							'user_agent' => $h["user_agent"]
						 );

	tep_db_perform(TABLE_ORDERS_MAXMIND_PARAMETERS, $sql_data_array);

// If you have cURL and an SSL connection available, leave the next line uncommented
// Otherwise comment it our by adding "//" in front of it.
// You need to make sure this is set to  meet your server
// you can check that under admin -> Tools -> Server Info. (Sam@samplusplus.com)

$ccfs->isSecure = 0;

// Set the time out to be five seconds

$ccfs->timeout = 5;

$ccfs->input($h);
$ccfs->query();
$h = $ccfs->output();
$outputkeys = array_keys($h);

$sql_data_array = array('order_id' => $insert_id,
							'anonymous_proxy' => $h['anonymousProxy'],
							'bin_country' => $h['binCountry'],
							'bin_match' => $h['binMatch'],
							'bin_name' => $h['binName'],
							'binNameMatch' => $h['binNameMatch'],
							'binPhone' => $h['binPhone'],
							'carderEmail' => $h['carderEmail'],
							'cityPostalMatch' => $h['cityPostalMatch'],
							'country_code' => $h['countryCode'],
							'country_match' => $h['countryMatch'],
							'cust_phone' => $h['custPhoneInBillingLoc'],
							'distance' => $h['distance'],
							'err' => $h['err'],
							'explanation' => $h['explanation'],
							'free_mail' => $h['freeMail'],
							'hi_risk' => $h['highRiskCountry'],
							'highRiskPassword' => $h['highRiskPassword'],
							'ip_accuracyRadius' => $h['ip_accuracyRadius'],
							'ip_address' => $ip,
							'ip_area_code' => $h['ip_areaCode'],
							'ip_city' => $h['ip_city'],
							'ip_cityConf' => $h['ip_cityConf'],
							'ip_continentCode' => $h['ip_continentCode'],
							'ip_corporateProxy' => $h['ip_corporateProxy'],
							'ip_country_name' => $h['ip_countryName'],
							'ip_countryConf' => $h['ip_countryConf'],
							'ip_domain' => $h['ip_domain'],
							'ip_isp' => $h['ip_isp'],
							'ip_latitude' => $h['ip_latitude'],
							'ip_longitude' => $h['ip_longitude'],
							'ip_metroCode' => $h['ip_metroCode'],
							'ip_net_speed' => $h['ip_netSpeedCell'],
							'ip_org' => $h['ip_org'],
							'ip_postal_code' => $h['ip_postalCode'],
							'ip_postalConf' => $h['ip_postalConf'],
							'ip_region' => $h['ip_region'],
							'ip_region_name' => $h['ip_regionName'],
							'ip_regionConf' => $h['ip_regionConf'],
							'ip_time_zone' => $h['ip_timeZone'],
							'ip_user_type' => $h['ip_userType'],
							'isTransProxy' => $h['isTransProxy'],
							'maxmindID' => $h['maxmindID'],
							'minfraud_version' => $h['minfraud_version'],
							'prepaid' => $h['prepaid'],
							'proxy_score' => $h['proxyScore'],
							'queriesRemaining' => $h['queriesRemaining'],
							'risk' => $h['riskScore'],
							'score' => $h['score'],
							'service_level' => $h['service_level'],
							'ship_forward' => $h['shipForward'],
							'shipCityPostalMatch' => $h['shipCityPostalMatch']
						 );

	tep_db_perform(TABLE_ORDERS_MAXMIND, $sql_data_array);
?>