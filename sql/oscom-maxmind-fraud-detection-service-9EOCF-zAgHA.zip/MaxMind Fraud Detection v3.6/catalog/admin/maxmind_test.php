<?php
/*
  Maxmind_Test.php, v3.6, 29 March 2015

  Under GNU license and developed by 
  Noel "Splinter" Latsha, CISSP, ISO 27001, CEH, CIW Professional, CIW Database Design, CIW Site Design, SCJA, CWSP, E|DRP, E|CHFI, E|CEH, Project+, Network+, Security+, MCP 
  
**  All links will be kept original **
	**  All links will be kept original **
		**  All links will be kept original **
			**  All links will be kept original **
				**  All links will be kept original **
*/

require('includes/application_top.php');
require(DIR_WS_MODULES . 'maxmind/english.php');
require(DIR_WS_INCLUDES . 'template_top.php');
require(DIR_WS_MODULES . 'maxmind/CreditCardFraudDetection.php');
		
$insert_id = $_GET["orderID"];
$h["license_key"] = $_GET["licenseKey"];
$cc = $_GET["CC"];
$ip = $_GET["ipAddress"];
$requested_type = $_GET["requestedType"];
$txn_type = $_GET["transactionType"];


// *************************************DO NOT MODIFY BELOW THIS LINE (Unless you know what you are doing **********************************	   
$check_status_query = tep_db_query("select * from " . TABLE_ORDERS . " where orders_id = '" . (int)$insert_id . "'");
$check_status = tep_db_fetch_array($check_status_query);

$check_country_query = tep_db_query("select countries_iso_code_2 from " . TABLE_COUNTRIES . " where countries_name = '" . tep_db_input($sql_data_array['customers_country']) . "'");
$check_country = tep_db_fetch_array($check_country_query);

$check_delivery_country_query = tep_db_query("select countries_iso_code_2 from " . TABLE_COUNTRIES . " where countries_name = '" . tep_db_input($sql_data_array['delivery_country']) . "'");
$check_delivery_country = tep_db_fetch_array($check_delivery_country_query);

$check_state_query = tep_db_query("select zone_code from " . TABLE_ZONES . " where zone_name = '" . tep_db_input($sql_data_array['customers_state']) . "'");
$check_state = tep_db_fetch_array($check_state_query);

$check_delivery_state_query = tep_db_query("select zone_code from " . TABLE_ZONES . " where zone_name = '" . tep_db_input($sql_data_array['delivery_state']) . "'");
$check_delivery_state = tep_db_fetch_array($check_delivery_state_query);

$check_customer_information_query = tep_db_query("select customers_password from " . TABLE_CUSTOMERS . " where customers_id = '" . tep_db_input($sql_data_array['customers_id']) . "'");
$check_customer_information = tep_db_fetch_array($check_customer_information_query);

$ccfs = new CreditCardFraudDetection;

//Email Address Split
$str = $check_status['customers_email_address'];
list ($addy, $domain) = preg_split ('[@]', $str);
$email_address = strtolower($str);
$email_MD5 = md5($email_address);

//Next we set inputs and store them in a hash
$h["bin"] = $cc;
$h["city"] = $check_status['customers_city'];    
$h["country"] = $check_country['countries_iso_code_2'];  
$h["custPhone"] = $check_status['customers_telephone'];
$h["domain"] = $domain; 
$h["emailMD5"] = $email_MD5;
$h["i"] = $ip;
// $h["order_amount"] = $order_amount;  //Future Use
$h["order_currency"] = $check_status['currency'];
$h["passwordMD5"] = $check_customer_information['customers_password'];
$h["postal"] = $check_status['customers_postcode'];    
$h["region"] = $check_state['zone_code'];       
$h["sessionID"] = session_id();
$h["shipAddr"] = $check_status['delivery_street_address'];
$h["shipCity"] = $check_status['delivery_city'];
$h["shipCountry"] = $check_delivery_country['countries_iso_code_2'];
$h["shipPostal"] = $check_status['delivery_postcode'];
$h["shipRegion"] = $check_delivery_state['zone_code'];
$h["txn_type"] = $txn_type;
$h["txnID"] = $insert_id;
$h['accept_language'] = getenv("HTTP_ACCEPT_LANGUAGE");
$h['forwardedIP'] = getenv("HTTP_X_FORWARDED_FOR");
$h['requested_type'] = $requested_type;
$h['user_agent'] = getenv("HTTP_USER_AGENT");
$h['usernameMD5'] = $email_MD5;


$sql_data_array = array('order_id' => $insert_id,
							'accept_language' => $h["accept_language"],
							'bin' => $h["bin"],
							'city' => $h["city"],
							'country' => $h["country"],
							'custPhone' => $h["custPhone"],
							'domain' => $h["domain"],
							'emailMD5' => $h["emailMD5"],
							'forwardedIP' => $h["forwardedIP"],
							'ip_address' => $h["i"],
							'license_key' => $h["license_key"],
							'order_amount' => $h["order_amount"],
							'order_currency' => $h["order_currency"],
							'passwordMD5' => $h["passwordMD5"],
							'postal' => $h["postal"],
							'region' => $h["region"],
							'requested_type' => $h["requested_type"],
							'sessionID' => $h["sessionID"],
							'shipAddr' => $h["shipAddr"],
							'shipCity' => $h["shipCity"],
							'shipCountry' => $h["shipCountry"],
							'shipPostal' => $h["shipPostal"],
							'shipRegion' => $h["shipRegion"],
							'txnID' => $h["txnID"],
							'txn_type' => $h["txn_type"],     
							'usernameMD5' => $h["usernameMD5"],
							'user_agent' => $h["user_agent"]	
						 );

	tep_db_perform(TABLE_ORDERS_MAXMIND_PARAMETERS, $sql_data_array);

?>
<table border="4" width="50%">
	<tr class="dataTableRow">
		<td colspan="2" class="main" align="center" valign="middle"><b><br /><?php echo MAXMIND_TEST_PAGE_INSTRUCTIONS; ?><br /><br /></b><?php echo MAXMIND_QUERY_HISTORY; ?><br /><br /></td>
    </tr>
    <tr>
		<td colspan="2" class="main" align="center" valign="middle"><b><br /><?php echo MAXMIND_SENT; ?><br /><br /></b></td>
    </tr>
<?php

$outputkeys = array_keys($h);
$numoutputkeys = count($h);
for ($i = 0; $i < $numoutputkeys; $i++) {
	$key = $outputkeys[$i];
	$value = $h[$key];
	
	switch  ($key) {
			case "bin" : $fieldDescription = MAXMIND_BANK_ID; break;
			case "city" : $fieldDescription = MAXMIND_CITY; break;
			case "country" : $fieldDescription = MAXMIND_COUNTRY; break;
			case "custPhone" : $fieldDescription = MAXMIND_CUSTOMER_PHONE; break;
			case "domain" : $fieldDescription = MAXMIND_DOMAIN; break;
			case "emailMD5" : $fieldDescription = MAXMIND_EMAIL_MD5; break;
			case "i" : $fieldDescription = MAXMIND_IP_ADDRESS; break;
			case "license_key" : $fieldDescription = MAXMIND_LICENSE_KEY; break;
			case "order_currency" : $fieldDescription = MAXMIND_ORDER_CURRENCY; break;
			case "passwordMD5" : $fieldDescription = MAXMIND_PASSWORD_MD5; break;
			case "postal" : $fieldDescription = MAXMIND_POSTAL_CODE; break;
			case "region" : $fieldDescription = MAXMIND_REGION; break;
			case "sessionID" : $fieldDescription = MAXMIND_SESSION_ID; break;
			case "shipAddr" : $fieldDescription = MAXMIND_SHIPPING_ADDRESS; break;
			case "shipCity" : $fieldDescription = MAXMIND_SHIPPING_CITY; break;
			case "shipCountry" : $fieldDescription = MAXMIND_SHIPPING_COUNTRY; break;
			case "shipPostal" : $fieldDescription = MAXMIND_SHIPPING_POSTAL_CODE; break;
			case "shipRegion" : $fieldDescription = MAXMIND_SHIPPING_REGION; break;
			case "txn_type" : $fieldDescription = MAXMIND_TRANSACTION_TYPE; break;
			case "txnID" : $fieldDescription = MAXMIND_TRANSACTION_ID; break;
			case "accept_language" : $fieldDescription = MAXMIND_ACCEPT_LANGUAGE; break;
			case "forwardedIP" : $fieldDescription = MAXMIND_FORWARDED_IP; break;
			case "requested_type" : $fieldDescription = MAXMIND_REQUESTED_TYPE; break;
			case "user_agent" : $fieldDescription = MAXMIND_USER_AGENT; break;
			case "usernameMD5" : $fieldDescription = MAXMIND_USERNAME_MD5; break;
			default : $fieldDescription = "UNDEFINED"; break;
		}	
	
	if ($i % 2 == 0) {
	?>
		<tr class="dataTableRow">
        <td width="5%" class="dataTableContent" valign="bottom"><?php echo '<b>'  . $fieldDescription . " (" . $key . ')</b>'; ?></td>
		<td width="25%" class="dataTableContent" valign="bottom"><?php echo $value; ?></td>
		</tr>
	<?php
	} else {
	?>
		<tr>
		<td width="5%" class="dataTableContent" valign="bottom"><?php echo '<b>'  . $fieldDescription . " (" . $key . ')</b>'; ?></td>
		<td width="25%" class="dataTableContent" valign="bottom"><?php echo $value; ?></td>
		</tr>
	<?php
	}
}

// If you have cURL and an SSL connection available, leave the next line uncommented
// Otherwise comment it our by adding "//" in front of it.
$ccfs->isSecure = 0;

//set the time out to be five seconds
$ccfs->timeout = 5;

//uncomment to turn on debugging
//$ccfs->debug = 1;

$ccfs->input($h);
$ccfs->query();
$h = $ccfs->output();
$outputkeys = array_keys($h);


$sql_data_array = array('order_id' => $insert_id,
							'anonymous_proxy' => $h['anonymousProxy'],
							'bin_country' => $h['binCountry'],
							'bin_match' => $h['binMatch'],
							'bin_name' => $h['binName'],
							'binNameMatch' => $h['binNameMatch'],
							'binPhone' => $h['binPhone'],
							'carderEmail' => $h['carderEmail'],
							'cityPostalMatch' => $h['cityPostalMatch'],
							'country_code' => $h['countryCode'],
							'country_match' => $h['countryMatch'],
							'cust_phone' => $h['custPhoneInBillingLoc'],
							'distance' => $h['distance'],
							'err' => $h['err'],
							'explanation' => $h['explanation'],
							'free_mail' => $h['freeMail'],                     
							'hi_risk' => $h['highRiskCountry'],
							'highRiskPassword' => $h['highRiskPassword'],
							'ip_accuracyRadius' => $h['ip_accuracyRadius'],
							'ip_address' => $ip, 
							'ip_area_code' => $h['ip_areaCode'],
							'ip_city' => $h['ip_city'],
							'ip_cityConf' => $h['ip_cityConf'],
							'ip_continentCode' => $h['ip_continentCode'],
							'ip_corporateProxy' => $h['ip_corporateProxy'],
							'ip_country_name' => $h['ip_countryName'],
							'ip_countryConf' => $h['ip_countryConf'],
							'ip_domain' => $h['ip_domain'],
							'ip_isp' => $h['ip_isp'],
							'ip_latitude' => $h['ip_latitude'],
							'ip_longitude' => $h['ip_longitude'],
							'ip_metroCode' => $h['ip_metroCode'], 
							'ip_net_speed' => $h['ip_netSpeedCell'], 
							'ip_org' => $h['ip_org'],
							'ip_postal_code' => $h['ip_postalCode'],
							'ip_postalConf' => $h['ip_postalConf'],
							'ip_region' => $h['ip_region'],
							'ip_region_name' => $h['ip_regionName'],
							'ip_regionConf' => $h['ip_regionConf'],
							'ip_time_zone' => $h['ip_timeZone'],
							'ip_user_type' => $h['ip_userType'],
							'isTransProxy' => $h['isTransProxy'],
							'maxmindID' => $h['maxmindID'],
							'minfraud_version' => $h['minfraud_version'],
							'prepaid' => $h['prepaid'],
							'proxy_score' => $h['proxyScore'],
							'queriesRemaining' => $h['queriesRemaining'],
							'risk' => $h['riskScore'],
							'score' => $h['score'],
							'service_level' => $h['service_level'],
							'ship_forward' => $h['shipForward'],
							'shipCityPostalMatch' => $h['shipCityPostalMatch']
						 );
	tep_db_perform(TABLE_ORDERS_MAXMIND, $sql_data_array);
	
switch ($h['err']) {
	case "IP_NOT_FOUND" : $error_text = IP_NOT_FOUND; break;
	case "COUNTRY_NOT_FOUND" : $error_text = COUNTRY_NOT_FOUND; break;
	case "CITY_NOT_FOUND" : $error_text = CITY_NOT_FOUND; break;
	case "CITY_REQUIRED" : $error_text = CITY_REQUIRED; break;
	case "POSTAL_CODE_REQUIRED" : $error_text = POSTAL_CODE_REQUIRED; break;
	case "POSTAL_CODE_NOT_FOUND" : $error_text = POSTAL_CODE_NOT_FOUND; break;
	case "INVALID_LICENSE_KEY" : $error_text = INVALID_LICENSE_KEY; break;
	case "IP_REQUIRED" : $error_text = IP_REQUIRED; break;
	case "LICENSE_REQUIRED" : $error_text = LICENSE_REQUIRED; break;
	case "COUNTRY_REQUIRED" : $error_text = COUNTRY_REQUIRED; break;
	case "MAX_REQUESTS_REACHED" : $error_text = MAX_REQUESTS_REACHED; break;
	default: $error_text = 'No Errors'; break;
	}
	
?>	
	
	<tr class="dataTableRow">
		<td colspan="2" width="5%" class="main" align="center" valign="middle"><b><br /><?php echo MAXMIND_RECEIVED; ?><br /><br /></b></td>
    </tr>
    <tr>
		<td width="5%" class="main" align="left" valign="middle"><b><br /><?php echo MAXMIND_ERR; ?><br /><br /></b></td>
        <td width="5%" class="main" align="left" valign="middle"><b><?php echo '<b><font color="red">' . $error_text . '</b>'; ?></b></td>
    </tr>

	
<?php
	
	$outputkeys = array_keys($sql_data_array);
	$numoutputkeys = count($sql_data_array);
	for ($i = 0; $i < $numoutputkeys; $i++) {
	$key = $outputkeys[$i];
	$value = $sql_data_array[$key];
		switch  ($key) {
			case  order_id : $fieldDescription = 'Order ID: '; break; 
			case  anonymous_proxy : $fieldDescription =  MAXMIND_ANONYMOUS ; break; 
			case  bin_country : $fieldDescription =  MAXMIND_BIN_COUNTRY ; break; 
			case  bin_match : $fieldDescription =  MAXMIND_BIN_MATCH ; break; 
			case  bin_name : $fieldDescription =  MAXMIND_BIN_NAME ; break; 
			case  binNameMatch : $fieldDescription =  MAXMIND_BIN_NAME_MATCH ; break; 
			case  binPhone : $fieldDescription =  MAXMIND_BIN_PHONE_NUMBER ; break; 
			case  carderEmail : $fieldDescription =  MAXMIND_CARDER_EMAIL ; break; 
			case  cityPostalMatch : $fieldDescription =  MAXMIND_CITY_POSTAL_MATCH ; break; 
			case  country_code : $fieldDescription =  MAXMIND_CODE ; break; 
			case  country_match : $fieldDescription =  MAXMIND_COUNTRY_MATCH ; break; 
			case  cust_phone : $fieldDescription =  MAXMIND_CUST_PHONE ; break; 
			case  distance : $fieldDescription =  MAXMIND_DISTANCE ; break; 
			case  err : $fieldDescription =  MAXMIND_ERR ; break; 
			case  explanation : $fieldDescription =  MAXMIND_EXPLANATION ; break; 
			case  free_mail : $fieldDescription =  MAXMIND_FREE_EMAIL ; break; 
			case  hi_risk : $fieldDescription =  MAXMIND_HI_RISK ; break; 
			case  highRiskPassword : $fieldDescription =  MAXMIND_HI_RISK_PASSWORD ; break; 
			case  ip_accuracyRadius : $fieldDescription =  MAXMIND_IP_ACCURACY_RADIUS ; break; 
			case  ip_address : $fieldDescription =  MAXMIND_IP_ADDRESS ; break; 
			case  ip_area_code : $fieldDescription =  MAXMIND_IP_AREA_CODE ; break; 
			case  ip_city : $fieldDescription =  MAXMIND_IP_CITY ; break; 
			case  ip_cityConf : $fieldDescription = MAXMIND_IP_CITY . MAXMIND_CONFIDENCE; break; 
			case  ip_continentCode : $fieldDescription = MAXMIND_IP_CONTINENT_CODE; break; 
			case  ip_corporateProxy : $fieldDescription =  MAXMIND_PROXY_CORPORATE ; break; 
			case  ip_country_name : $fieldDescription =  MAXMIND_IP_COUNTRY ; break; 
			case  ip_countryConf : $fieldDescription =  MAXMIND_IP_COUNTRY .  MAXMIND_CONFIDENCE; break; 
			case  ip_domain : $fieldDescription = MAXMIND_IP_DOMAIN; break; 
			case  ip_isp : $fieldDescription =  MAXMIND_IP_ISP ; break; 
			case  ip_latitude : $fieldDescription =  MAXMIND_IP_LATITUDE ; break; 
			case  ip_longitude : $fieldDescription =  MAXMIND_IP_LONGITUDE ; break; 
			case  ip_metroCode : $fieldDescription = MAXMIND_IP_METROCODE; break; 
			case  ip_net_speed : $fieldDescription =  MAXMIND_IP_SPEED ; break; 
			case  ip_org : $fieldDescription =  MAXMIND_IP_ISP_ORG ; break; 
			case  ip_postal_code : $fieldDescription =  MAXMIND_IP_ZIP_CODE ; break; 
			case  ip_postalConf : $fieldDescription =  MAXMIND_IP_ZIP_CODE . MAXMIND_CONFIDENCE; break; 
			case  ip_region : $fieldDescription = MAXMIND_IP_REGION; break; 
			case  ip_region_name : $fieldDescription =  MAXMIND_IP_REGION ; break; 
			case  ip_regionConf : $fieldDescription =  MAXMIND_IP_REGION  . MAXMIND_CONFIDENCE; break; 
			case  ip_time_zone : $fieldDescription =  MAXMIND_IP_TIME_ZONE ; break; 
			case  ip_user_type : $fieldDescription =  MAXMIND_IP_USER_TYPE ; break; 
			case  isTransProxy : $fieldDescription =  MAXMIND_IS_TRANS_PROXY ; break; 
			case  maxmindID : $fieldDescription =  MAXMIND_ID ; break; 
			case  minfraud_version : $fieldDescription = MAXMIND_MINFRAUD_VERSION; break; 
			case  prepaid : $fieldDescription = MAXMIND_PREPAID; break; 
			case  proxy_score : $fieldDescription =  MAXMIND_PROXY_SCORE ; break; 
			case  queriesRemaining : $fieldDescription =  MAXMIND_QUERIES_REMAINING ; break; 
			case  risk : $fieldDescription =  MAXMIND_RISK ; break; 
			case  score : $fieldDescription =  MAXMIND_SCORE ; break; 
			case  service_level : $fieldDescription = MAXMIND_SERVICE_LEVEL; break; 
			case  ship_forward : $fieldDescription = MAXMIND_SHIP_FORWARD; break; 
			case  shipCityPostalMatch : $fieldDescription =  MAXMIND_SHIP_CITY_POSTAL_MATCH ; break; 
			default : $fieldDescription = " UNDEFINED"; break;
		}
	if ($i % 2 == 0) {
	?>
		<tr class="dataTableRow">
		<td width="10%" class="dataTableContent" valign="bottom"><?php echo '<b>'  . $fieldDescription . " (" . $key . ')</b>'; ?></td>
		<td width="25%" class="dataTableContent" valign="bottom"><?php echo $value; ?></td>
		</tr>
	<?php
	} else {
	?>
		<tr>
		<td width="10%" class="dataTableContent" valign="bottom"><?php echo '<b>'  . $fieldDescription . " (" . $key . ')</b>'; ?></td>
		<td width="25%" class="dataTableContent" valign="bottom"><?php echo $value; ?></td>
		</tr>
	<?php
	}
}
  require(DIR_WS_INCLUDES . 'template_bottom.php');
  require(DIR_WS_INCLUDES . 'application_bottom.php');
?>