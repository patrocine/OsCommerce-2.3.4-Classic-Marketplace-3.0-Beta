<?php
/*
  Languages file for Maxmind mod, v3.6, 29 March 2015

  Under GNU license and developed by 
  Noel "Splinter" Latsha, CISSP, ISO 27001, CEH, CIW Professional, CIW Database Design, CIW Site Design, SCJA, CWSP, E|DRP, E|CHFI, E|CEH, Project+, Network+, Security+, MCP 
  
**  All links will be kept original **
	**  All links will be kept original **
		**  All links will be kept original **
			**  All links will be kept original **
				**  All links will be kept original **

// Maxmind Mod Noel Latsha

*/
define('CITY_NOT_FOUND', 'Warning: City could not be found');
define('CITY_REQUIRED', 'Warning: City input is required ');
define('COUNTRY_NOT_FOUND', 'Warning: Country could not be found ');
define('COUNTRY_REQUIRED', 'Fatal Error: Country is required ');
define('INVALID_LICENSE_KEY', 'Fatal Error: Invalid License Key ');
define('IP_NOT_FOUND', 'Warning: IP could not be found ');
define('IP_REQUIRED', 'Fatal Error: IP address is required ');
define('LICENSE_REQUIRED', 'Fatal Error: <a href="https://www.maxmind.com/en/ccv2r_signup?rId=nabcom" target="_blank" class="dataTableContent"><u>MaxMind.com License is required</u></a> ');
define('MAX_REQUESTS_PER_LICENSE', 'Fatal Error: Maximum number of requests reached for your license. <a href="https://www.maxmind.com/en/ccv2r_signup?rId=nabcom" target="_blank"><u>Upgrade Now!</u></a>  ');
define('MAX_REQUESTS_REACHED', 'Fatal Error: Maximun number of requests reached. <a href="https://www.maxmind.com/en/ccv2r_signup?rId=nabcom" target="_blank"><u>Upgrade Now!</u></a>  ');
define('MAXMIND_ACCEPT_LANGUAGE', 'Accept Language:  ');
define('MAXMIND_ACCOUNT_INFORMATION', 'Account Information  ');
define('MAXMIND_ADDRESS_INFORMATION', 'Address Information ');
define('MAXMIND_ANONYMOUS', 'Anonymous Proxy:  ');
define('MAXMIND_AUTHORIZE_NET', '<a href="http://reseller.authorize.net/application?id=5558643">(Authorize.net)</a>');
define('MAXMIND_AUTHORIZE_NET_SIGNUP', '<a href="http://reseller.authorize.net/application?id=5558643"> Goto Authorize.net!</a>');
define('MAXMIND_AVAILABLE_ORDERS', 'Available Orders (Paid with Credit Card)');
define('MAXMIND_BANK_ID', 'Bank ID:  ');
define('MAXMIND_BANK_INFORMATION', 'Bank Information ');
define('MAXMIND_BIN_COUNTRY', '<b>*Bank Country: </b> ');
define('MAXMIND_BIN_COUNTRY_MATCH', 'Bank Country Match:  ');
define('MAXMIND_BIN_MATCH', 'Bank Match:  ');
define('MAXMIND_BIN_NAME', '<b>*Bank Name: </b> ');
define('MAXMIND_BIN_NAME_MATCH', 'BIN Name Match:  ');
define('MAXMIND_BIN_PHONE_NUMBER', '<b>*Bank Phone Number: </b> ');
define('MAXMIND_CARDER_EMAIL', 'Hi-Risk Email Address:  ');
define('MAXMIND_CITY', 'City:  ');
define('MAXMIND_CITY_POSTAL_MATCH', 'Billing City/State match:  ');
define('MAXMIND_CODE', 'Country Code:  ');
define('MAXMIND_CONFIDENCE', '(Confidence)  ');
define('MAXMIND_COUNTRY', 'Country:  ');
define('MAXMIND_COUNTRY_MATCH', 'IP Matches Billing Country:  ');
define('MAXMIND_CUST_PHONE', 'Phone Matches Billing Location:  ');
define('MAXMIND_CUSTOMER_NAME', 'Customer Name');
define('MAXMIND_CUSTOMER_PHONE', 'Customer Phone:  ');
define('MAXMIND_DATE', 'Date');
define('MAXMIND_DETAILS', 'See <a href="http://dev.maxmind.com/minfraud/#Output-12?rId=nabcom" target="_blank"><u>MaxMind.com</u></a> for explanation of the following fields ');
define('MAXMIND_DISTANCE', 'Distance:  ');
define('MAXMIND_DOMAIN', 'Domain:  ');
define('MAXMIND_EMAIL_CHECKS', 'Email Checks ');
define('MAXMIND_EMAIL_MD5', 'EMail MD5:  ');
define('MAXMIND_ERR', 'Error:  ');
define('MAXMIND_EXPLANATION', 'Explanation:  ');
define('MAXMIND_EXPLANATION_ALL_FIELDS', '<a href="http://dev.maxmind.com/minfraud/#Output-12?rId=nabcom">Expanation for all fields here</a>');
define('MAXMIND_FORWARDED_IP', 'Forwarded IP:  ');
define('MAXMIND_FREE_EMAIL', 'Free Email:  ');
define('MAXMIND_HI_RISK', 'High Risk Country:  ');
define('MAXMIND_HI_RISK_PASSWORD', 'High Risk Password:  ');
define('MAXMIND_ID', 'MaxMind ID:  ');
define('MAXMIND_IP_ACCURACY_RADIUS', 'IP Accuracy Radius:  ');
define('MAXMIND_IP_ADDRESS', 'IP Address:  ');
define('MAXMIND_IP_AREA_CODE', 'ISP Org:  ');
define('MAXMIND_IP_CITY', 'IP Origination City:  ');
define('MAXMIND_IP_CONTINENT_CODE', 'IP Continent Code: ');
define('MAXMIND_IP_COUNTRY', 'IP Origination Country:  ');
define('MAXMIND_IP_DOMAIN', 'IP Domain: ');
define('MAXMIND_IP_INFORMATION', 'IP Information ');
define('MAXMIND_IP_ISP', 'ISP:  ');
define('MAXMIND_IP_ISP_ORG', 'ISP Org:  ');
define('MAXMIND_IP_LATITUDE', 'IP Latitude:  ');
define('MAXMIND_IP_LONGITUDE', 'IP Longitude:  ');
define('MAXMIND_IP_METROCODE', 'IP Metro Code: ');
define('MAXMIND_IP_REGION', 'IP Origination Region:  ');
define('MAXMIND_IP_SPEED', 'IP Network Speed:  ');
define('MAXMIND_IP_TIME_ZONE', 'IP Timezone:  ');
define('MAXMIND_IP_USER_TYPE', 'IP User Type:  ');
define('MAXMIND_IP_ZIP_CODE', 'IP Zip Code if available:  ');
define('MAXMIND_IS_TRANS_PROXY', 'Transparent Proxy:  ');
define('MAXMIND_ITEM', 'Item ');
define('MAXMIND_LICENSE_KEY', 'License Key:  ');
define('MAXMIND_MAIL_FORWARD', 'Known Forwarder:  ');
define('MAXMIND_MAXMIND', 'Maxmind ');
define('MAXMIND_MINFRAUD_VERSION', 'Minfraud API Version: ');
define('MAXMIND_NOT_IMPLEMENTED', 'Not Implemented (Yet) ');
define('MAXMIND_ORDER_AMOUNT', 'Order Amount:  ');
define('MAXMIND_ORDER_CURRENCY', 'Currency Used:  ');
define('MAXMIND_ORDER_NUMBER', 'Order Number ');
define('MAXMIND_PASSWORD_MD5', 'Password MD5:  ');
define('MAXMIND_PAYMENT_METHOD', 'Payment Method');
define('MAXMIND_POSTAL_CODE', 'Zip Code:  ');
define('MAXMIND_PREMIUM', '<b>*NOTE: You need to be subscribed to Premium Services at <a href="https://www.maxmind.com/en/ccfd_features?rId=nabcom" target="_blank"><u>MaxMind.com</u></a> for these fields: Bank Name, Bank Country and Bank Phone Number</b> ');
define('MAXMIND_PREMIUM_FEATURES', 'Premium Features:  ');
define('MAXMIND_PREPAID', 'Prepaid Card: ');
define('MAXMIND_PROXY_ANONYMOUS', 'Anonymous Proxy: ');
define('MAXMIND_PROXY_CORPORATE', 'Corporate Proxy:  ');
define('MAXMIND_PROXY_DETECTION', 'Proxy Detection: ');
define('MAXMIND_PROXY_SCORE', 'Proxy Score:  ');
define('MAXMIND_QUERIES_REMAINING', 'Queries Remaining:  ');
define('MAXMIND_QUERY_HISTORY', '<a href="https://www.maxmind.com/en/minfraud_log?rId=nabcom">Verify on Maxmind.com Query History</a>');
define('MAXMIND_RECEIVED', 'Information RETURNED from Maxmind');
define('MAXMIND_REGION', 'Region:  ');
define('MAXMIND_REQUESTED_TYPE', 'Requested Type:  ');
define('MAXMIND_RISK', 'RISK Score (0-100): <a href="https://www.maxmind.com/en/riskscore?rId=nabcom">Explain </a> ');
define('MAXMIND_SCORE', 'Original Score: ');
define('MAXMIND_SENT', 'Information SENT to Maxmind');
define('MAXMIND_SERVICE_LEVEL', 'Query Type: ');
define('MAXMIND_SESSION_ID', 'Session ID:  ');
define('MAXMIND_SHIP_CITY_POSTAL_MATCH', 'Ship City Zip Code Match:  ');
define('MAXMIND_SHIP_FORWARD', 'Forwarding Address: ');
define('MAXMIND_SHIPPING_ADDRESS', 'Shipping Address:  ');
define('MAXMIND_SHIPPING_CITY', 'Shipping City:  ');
define('MAXMIND_SHIPPING_COUNTRY', 'Shipping Country:  ');
define('MAXMIND_SHIPPING_POSTAL_CODE', 'Shipping Zip Code:  ');
define('MAXMIND_SHIPPING_REGION', 'Shipping Region:  ');
define('MAXMIND_SPAM', 'Spam Score:  ');
define('MAXMIND_TEST_PAGE', 'Maxmind Test Page');
define('MAXMIND_TEST_PAGE_INSTRUCTIONS', 'Check below for any errors');
define('MAXMIND_TRANSACTION_ID', 'Transaction ID:  ');
define('MAXMIND_TRANSACTION_TYPE', 'Transaction Type: ');
define('MAXMIND_USER_AGENT', 'User Agent:  ');
define('MAXMIND_USERNAME_MD5', 'Username MD5:  ');
define('MAXMIND_VALUE', 'Value:  ');
define('POSTAL_CODE_NOT_FOUND', 'Warning: Postal code could not be found ');
define('POSTAL_CODE_REQUIRED', 'Warning: Postal code input is required ');

?>