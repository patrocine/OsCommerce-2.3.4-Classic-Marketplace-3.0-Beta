<?php

/* Additional table for Maxmind CC check by Noel Latsha

  OrderTableAddition.php,v 3.2, 3 Nov 2012

  Under GNU license and developed by 
  Noel "Splinter" Latsha, CISSP, ISO 27001, CEH, CIW Professional, CIW Database Design, CIW Site Design, SCJA, CWSP, E|DRP, E|CHFI, E|CEH, Project+, Network+, Security+, MCP 
  
**  All links will be kept original **
	**  All links will be kept original **
		**  All links will be kept original **
			**  All links will be kept original **
				**  All links will be kept original **

  */

  
$check_maxmind_query = tep_db_query("select * from " . TABLE_ORDERS_MAXMIND . " where order_id = '" . (int)$oID . "'");
$maxmind_query = tep_db_fetch_array($check_maxmind_query);

$check_maxmind_parameters_query = tep_db_query("select * from " . TABLE_ORDERS_MAXMIND_PARAMETERS . " where order_id = '" . (int)$oID . "'");
$maxmind_parameters_query = tep_db_fetch_array($check_maxmind_parameters_query);

if (tep_not_null($maxmind_query)) 
	{

	require(DIR_WS_MODULES . 'maxmind/english.php');
	$max_score = round($maxmind_query['risk'], -1);
	// echo $max_score;
	switch ($max_score) {
	case 0: 
		$max_comment = '(Extremely Low risk)'; 
		$max_image = "Bar_0.png";
		break;
	case 10: 
		$max_comment = '(Very Low risk)';
		$max_image = "Bar_1.png";
		break;
	case 20: 
		$max_comment = '(Low risk)'; 
		$max_image = "Bar_2.png";
		break;
	case 30: 
		$max_comment = '(Low risk)';
		$max_image = "Bar_3.png";
		break;
	case 40: 
		$max_comment = '(Low-Medium risk)';
		$max_image = "Bar_4.png";
		break;
	case 50: 
		$max_comment = '(Medium risk)';
		$max_image = "Bar_5.png";
		break;
	case 60: 
		$max_comment = '(Medium-high risk)';
		$max_image = "Bar_6.png";
		break;	
	case 70: 
		$max_comment = '(High risk)';
		$max_image = "Bar_7.png";
		break;	
	case 80: 
		$max_comment = '(Very High risk)';
		$max_image = "Bar_8.png";
		break;
	case 90: 
		$max_comment = '(Extremely High risk)';
		$max_image = "Bar_9.png";
		break;	
	case 100: 
		$max_comment = '(I can smell the fraud from here)';
		$max_image = "Bar_10.png";
		break;
	default: 
		$max_comment = 'Error in Processing'; 
		$max_image = "Bar_empty.png";
		break;
	}

	switch ($maxmind_query['err']) {
	case "IP_NOT_FOUND" : $error_text = IP_NOT_FOUND; break;
	case "COUNTRY_NOT_FOUND" : $error_text = COUNTRY_NOT_FOUND; break;
	case "CITY_NOT_FOUND" : $error_text = CITY_NOT_FOUND; break;
	case "CITY_REQUIRED" : $error_text = CITY_REQUIRED; break;
	case "POSTAL_CODE_REQUIRED" : $error_text = POSTAL_CODE_REQUIRED; break;
	case "POSTAL_CODE_NOT_FOUND" : $error_text = POSTAL_CODE_NOT_FOUND; break;
	case "INVALID_LICENSE_KEY" : $error_text = INVALID_LICENSE_KEY; break;
	case "MAX_REQUESTS_PER_LICENSE" : $error_text = MAX_REQUESTS_PER_LICENSE; break;
	case "IP_REQUIRED" : $error_text = IP_REQUIRED; break;
	case "LICENSE_REQUIRED" : $error_text = LICENSE_REQUIRED; break;
	case "License Key Required - visit http://www.maxmind.com/app/ccv2r_signup for free signup" : $error_text = LICENSE_REQUIRED; break;
	case "COUNTRY_REQUIRED" : $error_text = COUNTRY_REQUIRED; break;
	case "MAX_REQUESTS_REACHED" : $error_text = MAX_REQUESTS_REACHED; break;
	default: $error_text = 'No Errors'; break;
	}
	

	?>
	<script type="text/javascript"><!--
function showHide(elementid){
    if (document.getElementById(elementid).style.display == 'none'){
        document.getElementById(elementid).style.display = '';
    } else {
        document.getElementById(elementid).style.display = 'none';
    }
}
</script>

	</table>
	<table>	
		<tr> 
				<br><center>
	<?php 
	echo '<b class="main">', $max_comment, '<b>  <font color="red">' . $maxmind_query['risk'] . ' % chance of fraud</font></b><br>';
	echo tep_image(DIR_WS_MODULES . 'maxmind/images/' . $max_image, $max_comment); ?></center>

		</b></tr>
	</table>
	<table width="100%" cellpadding="2" cellspacing="0" border="2">
	<tr><br><br>
	<td width="12%" class="main" align="center" valign="middle"><br></td>
	<td width="12%" class="main" align="center" valign="middle"><?php echo '<b>' . MAXMIND_ITEM . '</b>'; ?></td>
	<td width="10%" class="main" align="center" valign="middle"><?php echo '<b>' . MAXMIND_VALUE . '</b>'; ?></td>
	<td width="12%" class="main" align="center" valign="middle"><?php echo '<b>' . MAXMIND_ITEM . '</b>'; ?></td>
	<td width="10%" class="main" align="center" valign="middle"><?php echo '<b>' . MAXMIND_VALUE . '</b>'; ?></td>
	<td width="12%" class="main" align="center" valign="middle"><?php echo '<b>' . MAXMIND_ITEM . '</b>'; ?></td>
	<td width="10%" class="main" align="center" valign="middle"><?php echo '<b>' . MAXMIND_VALUE . '</b>'; ?></td>
	</tr>
	<tr>
	<td width="12%" class="dataTableContent" align="center" valign="middle" rowspan=2><?php echo '<b>' . MAXMIND_MAXMIND; ?></td>
	<td width="12%" class="dataTableContent" valign="bottom"><?php echo MAXMIND_RISK; ?></td>
	<td width="10%" class="dataTableContent" valign="bottom"><?php echo '<b><font color="red">' . $maxmind_query['risk'] . ' % chance of fraud</font></b>'; ?></td>
	<td width="12%" class="dataTableContent" valign="bottom"><?php echo MAXMIND_ERR; ?></td>
	<td width="10%" class="dataTableContent" valign="bottom"><?php echo '<b><font color="red">' . $error_text . '</b>'; ?></td>
	<td width="12%" class="dataTableContent" valign="bottom"></td>
	<td width="10%" class="dataTableContent" valign="bottom"></td>
	</tr>
	<tr class="dataTableRow">
	<td width="12%" class="dataTableContent" valign="bottom"><?php echo MAXMIND_COUNTRY; ?></td>
	<td width="10%" class="dataTableContent" valign="bottom"><?php echo '<b>' . $maxmind_query['country_code']; ?></td>
	<td width="12%" class="dataTableContent" valign="bottom"><?php echo MAXMIND_COUNTRY_MATCH; ?></td>
	<td width="10%" class="dataTableContent" valign="bottom"><?php echo '<b>' . $maxmind_query['country_match'] . '</b>'; ?></td>
	<td width="12%" class="dataTableContent" valign="bottom"><?php echo MAXMIND_HI_RISK; ?></td>
	<td width="10%" class="dataTableContent" valign="bottom"><?php echo '<b>' . $maxmind_query['hi_risk'] . '</b>'; ?></td>
	</tr>
	<tr>
	<td width="12%" class="dataTableContent" align="center" valign="middle" rowspan=2><?php echo '<b>' . MAXMIND_BANK_INFORMATION; ?></td>
	<td width="12%" class="dataTableContent" valign="bottom"><?php echo MAXMIND_BIN_NAME; ?></td>
	<td width="10%" class="dataTableContent" valign="bottom"><?php echo '<b>' . $maxmind_query['bin_name']; ?></td>
	<td width="12%" class="dataTableContent" valign="bottom"><?php echo MAXMIND_BIN_COUNTRY_MATCH; ?></td>
	<td width="10%" class="dataTableContent" valign="bottom"><?php echo '<b>' . $maxmind_query['bin_match'] . '</b>'; ?></td>
	<td width="12%" class="dataTableContent" valign="bottom"><?php echo MAXMIND_BIN_COUNTRY; ?></td>
	<td width="10%" class="dataTableContent" valign="bottom"><?php echo '<b>' . $maxmind_query['bin_country'] . '</b>'; ?></td>
	</tr>
	<tr class="dataTableRow">
	<td width="12%" class="dataTableContent" valign="bottom"><?php echo MAXMIND_BIN_PHONE_NUMBER; ?></td>
	<td width="10%" class="dataTableContent" valign="bottom"><?php echo '<b>' . $maxmind_query['binPhone']; ?></td>
	<td width="12%" class="dataTableContent" valign="bottom" colspan=4></td>
	</tr>
	<tr>
	<td width="12%" class="dataTableContent" align="center" valign="middle" rowspan=2><?php echo '<b>' . MAXMIND_ADDRESS_INFORMATION; ?></td>
	<td width="12%" class="dataTableContent" valign="bottom"><?php echo MAXMIND_CUST_PHONE; ?></td>
	<td width="10%" class="dataTableContent" valign="bottom"><?php echo '<b>' . $maxmind_query['cust_phone']; ?></td>
	<td width="12%" class="dataTableContent" valign="bottom"><?php echo MAXMIND_MAIL_FORWARD; ?></td>
	<td width="10%" class="dataTableContent" valign="bottom"><?php echo '<b>' . $maxmind_query['ship_forward'] . '</b>'; ?></td>
	<td width="12%" class="dataTableContent" valign="bottom"><?php echo MAXMIND_CITY_POSTAL_MATCH; ?></td>
	<td width="10%" class="dataTableContent" valign="bottom"><?php echo '<b>' . $maxmind_query['cityPostalMatch'] . '</b>'; ?></td>
	</tr>
	<tr class="dataTableRow">
	<td width="12%" class="dataTableContent" valign="bottom"><?php echo MAXMIND_SHIP_CITY_POSTAL_MATCH; ?></td>
	<td width="10%" class="dataTableContent" valign="bottom"><?php echo '<b>' . $maxmind_query['shipCityPostalMatch']; ?></td>
	<td width="12%" class="dataTableContent" valign="bottom" colspan=4></td>
	</tr>
	<tr>
	<td width="12%" class="dataTableContent" align="center" valign="middle" rowspan=5><?php echo '<b>' . MAXMIND_IP_INFORMATION; ?></td>
	<td width="12%" class="dataTableContent" valign="bottom"><?php echo MAXMIND_IP_ADDRESS; ?></td>
	<td width="10%" class="dataTableContent" valign="bottom"><?php echo '<b>' . $maxmind_query['ip_address']; ?></td>
	<td width="12%" class="dataTableContent" valign="bottom"><?php echo MAXMIND_IP_CITY; ?></td>
	<td width="10%" class="dataTableContent" valign="bottom"><?php echo '<b>' . $maxmind_query['ip_city'] . '</b>'; ?></td>
	<td width="12%" class="dataTableContent" valign="bottom"><?php echo MAXMIND_IP_AREA_CODE; ?></td>
	<td width="10%" class="dataTableContent" valign="bottom"><?php echo '<b>' . $maxmind_query['ip_area_code'] . '</b>'; ?></td>
	</tr>
	<tr class="dataTableRow">
	<td width="12%" class="dataTableContent" valign="bottom"><?php echo MAXMIND_IP_COUNTRY . MAXMIND_CONFIDENCE; ?></td>
	<td width="10%" class="dataTableContent" valign="bottom"><?php echo '<b>' . $maxmind_query['ip_country_name'] . " (" . $maxmind_query['ip_countryConf'] . "%)" . '</b>'; ?></td>
	<td width="12%" class="dataTableContent" valign="bottom"><?php echo MAXMIND_IP_REGION . MAXMIND_CONFIDENCE; ?></td>
	<td width="10%" class="dataTableContent" valign="bottom"><?php echo '<b>' . $maxmind_query['ip_region_name'] . " (" . $maxmind_query['ip_regionConf'] . "%)" . '</b>'; ?></td>
	<td width="12%" class="dataTableContent" valign="bottom"><?php echo MAXMIND_IP_ZIP_CODE . MAXMIND_CONFIDENCE; ?></td>
	<td width="10%" class="dataTableContent" valign="bottom"><?php echo '<b>' . $maxmind_query['ip_postal_code'] . " (" . $maxmind_query['ip_postalConf'] . "%)" . '</b>'; ?></td>
	</tr>
	<tr>
	<td width="12%" class="dataTableContent" valign="bottom"><?php echo MAXMIND_IP_LATITUDE . "/" . MAXMIND_IP_LONGITUDE; ?></td>
	<td width="10%" class="dataTableContent" valign="bottom"><?php echo '<a href="http://maps.google.com/maps?q=IP Location@' . $maxmind_query['ip_latitude'] . ',' . $maxmind_query['ip_longitude'] . '">' . $maxmind_query['ip_latitude'] . '/' . $maxmind_query['ip_longitude'] . '</a>'; ?></td> 
	<td width="12%" class="dataTableContent" valign="bottom"><?php echo MAXMIND_DISTANCE; ?></td>
	<td width="10%" class="dataTableContent" valign="bottom"><?php echo '<b>' . $maxmind_query['distance'] . ' KM</b>'; ?></td>
	<td width="12%" class="dataTableContent" valign="bottom"><?php echo MAXMIND_IP_TIME_ZONE; ?></td>
	<td width="10%" class="dataTableContent" valign="bottom"><?php echo '<b>' . $maxmind_query['ip_time_zone'] . '</b>'; ?></td>
	</tr>
	<tr class="dataTableRow">
	<td width="12%" class="dataTableContent" valign="bottom"><?php echo MAXMIND_IP_ACCURACY_RADIUS; ?></td>
	<td width="10%" class="dataTableContent" valign="bottom"><?php echo '<b>' . $maxmind_query['ip_accuracyRadius'] . '</b>'; ?></td>
	<td width="12%" class="dataTableContent" valign="bottom"><?php echo MAXMIND_IP_USER_TYPE; ?></td>
	<td width="10%" class="dataTableContent" valign="bottom"><?php echo '<b>' . $maxmind_query['ip_user_type'] . '</b>'; ?></td>
	<td width="12%" class="dataTableContent" valign="bottom"><?php echo MAXMIND_IP_SPEED; ?></td>
	<td width="10%" class="dataTableContent" valign="bottom"><?php echo '<b>' . $maxmind_query['ip_net_speed'] . '</b>'; ?></td>
	</tr>
	<tr>
	<td width="12%" class="dataTableContent" valign="bottom"><?php echo MAXMIND_IP_ISP; ?></td>
	<td width="10%" class="dataTableContent" valign="bottom"><?php echo '<b>' . $maxmind_query['ip_isp'] . '</b>'; ?></td>
	<td width="12%" class="dataTableContent" valign="bottom"><?php echo MAXMIND_IP_ISP_ORG; ?></td>
	<td width="10%" class="dataTableContent" valign="bottom"><?php echo '<b>' . $maxmind_query['ip_org'] . '</b>'; ?></td>
	<td width="12%" class="dataTableContent" valign="bottom" colspan=2></td>
	</tr>
	<tr>
	<td width="12%" class="dataTableContent" align="center" valign="middle" rowspan=2><?php echo '<b>' . MAXMIND_PROXY_DETECTION; ?></td>
	<td width="12%" class="dataTableContent" valign="bottom" bgcolor="#F0F1F1"><?php echo MAXMIND_PROXY_DETECTION; ?></td>
	<td width="10%" class="dataTableContent" valign="bottom" bgcolor="#F0F1F1"><?php echo '<b>' . $maxmind_query['proxy_score'] . '</b>'; ?></td>
	<td width="12%" class="dataTableContent" valign="bottom" bgcolor="#F0F1F1"><?php echo MAXMIND_PROXY_ANONYMOUS; ?></td>
	<td width="10%" class="dataTableContent" valign="bottom" bgcolor="#F0F1F1"><?php echo '<b>' . $maxmind_query['anonymous_proxy'] . '</b>'; ?></td>
	<td width="12%" class="dataTableContent" valign="bottom" bgcolor="#F0F1F1"><?php echo MAXMIND_IS_TRANS_PROXY; ?></td>
	<td width="10%" class="dataTableContent" valign="bottom" bgcolor="#F0F1F1"><?php echo '<b>' . $maxmind_query['isTransProxy'] . '</b>'; ?></td>
	</tr>
	<tr>
	<td width="12%" class="dataTableContent" valign="bottom"><?php echo MAXMIND_PROXY_CORPORATE; ?></td>
	<td width="10%" class="dataTableContent" valign="bottom"><?php echo '<b>' . $maxmind_query['ip_corporateProxy'] . '</b>'; ?></td>
	<td width="12%" class="dataTableContent" valign="bottom" colspan=4></td>
	</tr>
	<tr>
	<td width="12%" class="dataTableContent" align="center" valign="middle"><?php echo '<b>' . MAXMIND_EMAIL_CHECKS; ?></td>
	<td width="12%" class="dataTableContent" valign="bottom" bgcolor="#F0F1F1"><?php echo MAXMIND_FREE_EMAIL; ?></td>
	<td width="10%" class="dataTableContent" valign="bottom" bgcolor="#F0F1F1"><?php echo '<b>' . $maxmind_query['free_mail'] . '</b>'; ?></td>
	<td width="12%" class="dataTableContent" valign="bottom" bgcolor="#F0F1F1"><?php echo MAXMIND_CARDER_EMAIL; ?></td>
	<td width="10%" class="dataTableContent" valign="bottom" bgcolor="#F0F1F1"><?php echo '<b>' . $maxmind_query['carderEmail'] . '</b>'; ?></td>
	<td width="12%" class="dataTableContent" valign="bottom" bgcolor="#F0F1F1"><?php echo MAXMIND_HI_RISK_PASSWORD; ?></td>
	<td width="10%" class="dataTableContent" valign="bottom" bgcolor="#F0F1F1"><?php echo '<b>' . $maxmind_query['highRiskPassword'] . '</b>'; ?></td>
	</tr>
	<tr>
	<td width="12%" class="dataTableContent" align="center" valign="middle"><?php echo '<b>' . MAXMIND_ACCOUNT_INFORMATION; ?></td>
	<td width="12%" class="dataTableContent" valign="bottom"><?php echo MAXMIND_QUERIES_REMAINING; ?></td>
	<td width="10%" class="dataTableContent" valign="bottom"><?php echo '<b>' . $maxmind_query['queriesRemaining'] . '</b>'; ?></td>
	<td width="12%" class="dataTableContent" valign="bottom"><?php echo MAXMIND_ID; ?></td>
	<td width="10%" class="dataTableContent" valign="bottom"><?php echo '<b>' . $maxmind_query['maxmindID'] . '</b>'; ?></td>
	<td width="12%" class="dataTableContent" valign="bottom"></td>
	<td width="10%" class="dataTableContent" valign="bottom"></td>
	</tr>
	<tr class="dataTableRow">
	<td class="main" colspan="7" valign="bottom"><?php echo '<b>' . MAXMIND_PREMIUM  . '</b>'; ?></td>
	</tr>
	<tr>
	<td colspan="7" valign="bottom"><center><a href="http://www.maxmind.com/app/fraud-detection-manual?rId=nabcom"  class="menuBoxHeadingLink" ><b>Explanation for all fields here</b></a></center></td>
	</tr>
		<tr>
	</tr>
	</tr>
	</table>
<br>	

 <div><a class="main" href="javascript:showHide('div_1');"><b><center>Click to open/close parameters passed to MaxMind ...</center></b></a></div>
<div id="div_1" style="display:none">

<table width="100%" cellpadding="2" cellspacing="0" border="2">
<tr><br><br>
	<td width="12%" class="main" align="center" valign="middle"><?php echo '<b>' . MAXMIND_ITEM . '</b>'; ?></td>
	<td width="10%" class="main" align="center" valign="middle"><?php echo '<b>' . MAXMIND_VALUE . '</b>'; ?></td>
	<td width="12%" class="main" align="center" valign="middle"><?php echo '<b>' . MAXMIND_ITEM . '</b>'; ?></td>
	<td width="10%" class="main" align="center" valign="middle"><?php echo '<b>' . MAXMIND_VALUE . '</b>'; ?></td>
	<td width="12%" class="main" align="center" valign="middle"><?php echo '<b>' . MAXMIND_ITEM . '</b>'; ?></td>
	<td width="10%" class="main" align="center" valign="middle"><?php echo '<b>' . MAXMIND_VALUE . '</b>'; ?></td>
	</tr>
	<tr>
	<td width="12%" class="dataTableContent" valign="bottom"><?php echo MAXMIND_ORDER_NUMBER; ?></td>
	<td width="10%" class="dataTableContent" valign="bottom"><?php echo '<b>' . $oID; ?></td>
	<td width="12%" class="dataTableContent" valign="bottom"><?php echo MAXMIND_SESSION_ID; ?></td>
	<td width="10%" class="dataTableContent" valign="bottom"><?php echo '<b>' . $maxmind_parameters_query['sessionID'] . '</b>'; ?></td>
	<td width="12%" class="dataTableContent" valign="bottom"><?php echo MAXMIND_TRANSACTION_ID; ?></td>
	<td width="10%" class="dataTableContent" valign="bottom"><?php echo '<b>' . $maxmind_parameters_query['txnID'] . '</b>'; ?></td>
	</tr>
	<tr class="dataTableRow">
	<td width="12%" class="dataTableContent" valign="bottom"><?php echo MAXMIND_TRANSACTION_TYPE; ?></td>
	<td width="10%" class="dataTableContent" valign="bottom"><?php echo '<b>' . $maxmind_parameters_query['txn_type'] . '</b>'; ?></td>
	<td width="12%" class="dataTableContent" valign="bottom"><?php echo MAXMIND_REQUESTED_TYPE; ?></td>
	<td width="10%" class="dataTableContent" valign="bottom"><?php echo '<b>' . $maxmind_parameters_query['requested_type'] . '</b>'; ?></td>
	<td width="12%" class="dataTableContent" valign="bottom"><?php echo MAXMIND_LICENSE_KEY; ?></td>
	<td width="10%" class="dataTableContent" valign="bottom"><?php echo '<b>' . $maxmind_parameters_query['license_key'] . '</b>'; ?></td>
	</tr>
		<tr>
	<td width="12%" class="dataTableContent" valign="bottom"><?php echo MAXMIND_IP_ADDRESS; ?></td>
	<td width="10%" class="dataTableContent" valign="bottom"><?php echo '<b>' . $maxmind_parameters_query['ip_address'] . '</b>'; ?></td>
	<td width="12%" class="dataTableContent" valign="bottom"><?php echo MAXMIND_FORWARDED_IP; ?></td>
	<td width="10%" class="dataTableContent" valign="bottom"><?php if (tep_not_null($maxmind_parameters_query['forwardedIP'])) { echo '<b>' . $maxmind_parameters_query['forwardedIP'] . '</b>'; } else echo '<b>N/A</b>'; ?></td>
	<td width="12%" class="dataTableContent" valign="bottom"></td>
	<td width="10%" class="dataTableContent" valign="bottom"></td>
	</tr>
	<tr class="dataTableRow">
	<td width="12%" class="dataTableContent" valign="bottom"><?php echo MAXMIND_DOMAIN; ?></td>
	<td width="10%" class="dataTableContent" valign="bottom"><?php echo '<b>' . $maxmind_parameters_query['domain'] . '</b>'; ?></td>
	<td width="12%" class="dataTableContent" valign="bottom"><?php echo MAXMIND_USERNAME_MD5; ?></td>
	<td width="10%" class="dataTableContent" valign="bottom"><?php echo '<b>' . $maxmind_parameters_query['usernameMD5'] . '</b>'; ?></td>
	<td width="12%" class="dataTableContent" valign="bottom"><?php echo MAXMIND_PASSWORD_MD5; ?></td>
	<td width="10%" class="dataTableContent" valign="bottom"><?php echo '<b>' . $maxmind_parameters_query['passwordMD5'] . '</b>'; ?></td>
	</tr>
	<tr>
	<td width="12%" class="dataTableContent" valign="bottom"><?php echo MAXMIND_EMAIL_MD5; ?></td>
	<td width="10%" class="dataTableContent" valign="bottom"><?php echo '<b>' . $maxmind_parameters_query['emailMD5'] . '</b>'; ?></td>
	<td width="12%" class="dataTableContent" valign="bottom"><?php echo MAXMIND_CUSTOMER_PHONE; ?></td>
	<td width="10%" class="dataTableContent" valign="bottom"><?php echo '<b>' . $maxmind_parameters_query['custPhone'] . '</b>'; ?></td>
	<td width="12%" class="dataTableContent" valign="bottom"></td>
	<td width="10%" class="dataTableContent" valign="bottom"></td>
	</tr>
	<tr class="dataTableRow">
	<td width="12%" class="dataTableContent" valign="bottom"><?php echo MAXMIND_ORDER_AMOUNT; ?></td>
	<td width="10%" class="dataTableContent" valign="bottom"><?php echo '<b>' . $maxmind_parameters_query['order_amount'] . '</b>'; ?></td>
	<td width="12%" class="dataTableContent" valign="bottom"><?php echo MAXMIND_ORDER_CURRENCY; ?></td>
	<td width="10%" class="dataTableContent" valign="bottom"><?php echo '<b>' . $maxmind_parameters_query['order_currency'] . '</b>'; ?></td>
	<td width="12%" class="dataTableContent" valign="bottom"><?php echo MAXMIND_BANK_ID; ?></td>
	<td width="10%" class="dataTableContent" valign="bottom"><?php echo '<b>' . $maxmind_parameters_query['bin'] . '</b>'; ?></td>
	</tr>
		<tr>
	<td width="12%" class="dataTableContent" valign="bottom"><?php echo MAXMIND_CITY; ?></td>
	<td width="10%" class="dataTableContent" valign="bottom"><?php echo '<b>' . $maxmind_parameters_query['city'] . '</b>'; ?></td>
	<td width="12%" class="dataTableContent" valign="bottom"><?php echo MAXMIND_REGION; ?></td>
	<td width="10%" class="dataTableContent" valign="bottom"><?php echo '<b>' . $maxmind_parameters_query['region'] . '</b>'; ?></td>
	<td width="12%" class="dataTableContent" valign="bottom"><?php echo MAXMIND_POSTAL_CODE; ?></td>
	<td width="10%" class="dataTableContent" valign="bottom"><?php echo '<b>' . $maxmind_parameters_query['postal'] . '</b>'; ?></td>
	</tr>
	<tr class="dataTableRow">
	<td width="12%" class="dataTableContent" valign="bottom"><?php echo MAXMIND_COUNTRY; ?></td>
	<td width="10%" class="dataTableContent" valign="bottom"><?php echo '<b>' . $maxmind_parameters_query['country'] . '</b>'; ?></td>
	<td width="12%" class="dataTableContent" valign="bottom"><?php echo MAXMIND_SHIPPING_ADDRESS?></td>
	<td width="10%" class="dataTableContent" valign="bottom"><?php echo '<b>' . $maxmind_parameters_query['shipAddr'] . '</b>'; ?></td>
	<td width="12%" class="dataTableContent" valign="bottom"><?php echo MAXMIND_SHIPPING_CITY; ?></td>
	<td width="10%" class="dataTableContent" valign="bottom"><?php echo '<b>' . $maxmind_parameters_query['shipCity'] . '</b>'; ?></td>
	</tr>
		<tr>
	<td width="12%" class="dataTableContent" valign="bottom"><?php echo MAXMIND_SHIPPING_COUNTRY; ?></td>
	<td width="10%" class="dataTableContent" valign="bottom"><?php echo '<b>' . $maxmind_parameters_query['shipCountry'] . '</b>'; ?></td>
	<td width="12%" class="dataTableContent" valign="bottom"><?php echo MAXMIND_SHIPPING_POSTAL_CODE; ?></td>
	<td width="10%" class="dataTableContent" valign="bottom"><?php echo '<b>' . $maxmind_parameters_query['shipPostal'] . '</b>'; ?></td>
	<td width="12%" class="dataTableContent" valign="bottom"><?php echo MAXMIND_SHIPPING_REGION; ?></td>
	<td width="10%" class="dataTableContent" valign="bottom"><?php echo '<b>' . $maxmind_parameters_query['shipRegion'] . '</b>'; ?></td>
	</tr>
	<tr class="dataTableRow">
	<td width="12%" class="dataTableContent" valign="bottom"><?php echo MAXMIND_ACCEPT_LANGUAGE; ?></td>
	<td width="10%" class="dataTableContent" valign="bottom"><?php echo '<b>' . $maxmind_parameters_query['accept_language'] . '</b>'; ?></td>
	<td width="12%" class="dataTableContent" valign="bottom"><?php echo MAXMIND_USER_AGENT; ?></td>
	<td width="10%" class="dataTableContent" valign="bottom" colspan=3><?php echo '<b>' . $maxmind_parameters_query['user_agent'] . '</b>'; ?></td>
	</tr>
</table>
</div>
<table>

	
	
<?php
}
?>