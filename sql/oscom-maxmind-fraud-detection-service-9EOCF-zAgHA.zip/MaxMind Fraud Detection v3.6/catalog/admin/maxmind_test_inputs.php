<?php
/*
  Maxmind_Test.php, v3.6, 29 March 2015

  Under GNU license and developed by 
  Noel "Splinter" Latsha, CISSP, ISO 27001, CEH, CIW Professional, CIW Database Design, CIW Site Design, SCJA, CWSP, E|DRP, E|CHFI, E|CEH, Project+, Network+, Security+, MCP 
  
**  All links will be kept original **
	**  All links will be kept original **
		**  All links will be kept original **
			**  All links will be kept original **
				**  All links will be kept original **
*/


require('includes/application_top.php');
require(DIR_WS_MODULES . 'maxmind/english.php');
require(DIR_WS_INCLUDES . 'template_top.php');

$get_cc_order_query = tep_db_query("select * from " . TABLE_ORDERS . " where payment_method = 'Credit Card (Processed by Authorize.net)'");
?>

<link href="includes/stylesheet.css" rel="stylesheet" type="text/css" />
<script type="text/javascript"><!--
function showHide(elementid){
    if (document.getElementById(elementid).style.display == 'none'){
        document.getElementById(elementid).style.display = '';
    } else {
        document.getElementById(elementid).style.display = 'none';
    }
}
</script>

<div>
	<a class="dataTableRowOver" href="javascript:showHide('div_1');"><center><br /><br /><b>Click to show some orders made using a Credit Card <?php echo MAXMIND_AUTHORIZE_NET; ?> ...</center></b></a></</div>
<div id="div_1" style="display:none"><br /><br />
    <table border="2" align="center" width="40%">
        <tr class="dataTableHeadingRow" align="center">
            <td colspan="4">
                <?php echo MAXMIND_AVAILABLE_ORDERS . MAXMIND_AUTHORIZE_NET_SIGNUP; ?>
            </td>
        </tr>
        <tr class="dataTableRow">
            <td align="center"><?php echo MAXMIND_ORDER_NUMBER; ?></td><td align="center"><?php echo MAXMIND_CUSTOMER_NAME; ?></td><td align="center"><?php echo MAXMIND_DATE; ?></td><td align="center"><?php echo MAXMIND_PAYMENT_METHOD; ?></td>
        </tr>
<?php
$i = 0;
while ($get_cc_order = tep_db_fetch_array($get_cc_order_query)) {
	$i++;
    if ($i % 2 == 0) {
		?>
	<tr class="dataTableRow">
        <td align="center" class="dataTableContent"><?php echo $get_cc_order[orders_id]; ?></td>
        <td align="center" class="dataTableContent"><?php echo $get_cc_order[customers_name]; ?></td>
        <td align="center" class="dataTableContent"><?php echo $get_cc_order[date_purchased]; ?></td>
        <td align="center" class="dataTableContent"><?php echo $get_cc_order[payment_method]; ?></td>
	<?php
    } else {
    ?>
  <tr>
        <td align="center" align="center" class="dataTableContent"><?php echo $get_cc_order[orders_id]; ?></td>
        <td align="center" class="dataTableContent"><?php echo $get_cc_order[customers_name]; ?></td>
        <td align="center" class="dataTableContent"><?php echo $get_cc_order[date_purchased]; ?></td>
        <td align="center" class="dataTableContent"><?php echo $get_cc_order[payment_method]; ?></td>
	<?php
 
  }
}
$i = 1; 
?>
        </tr>
    </table></div><br /><br /><br />
    <table border="5" align="center" cellpadding="4">
		<form action="maxmind_test.php">
		<tr>
        	<td class="dataTableContent">
 				Order ID:
     		</td>
            <td class="dataTableContent">
        		<input type="text" name="orderID">
          	</td>
        </tr>
        <tr>
        	<td class="dataTableContent">
  				License Key:
 			</td>
        <td class="dataTableContent"> 
  			<input type="text" name="licenseKey">
  		</td>
    </tr>
    <tr>
    	<td class="dataTableContent">
  			Credit Card # (first 6): 
 		</td>
       	<td class="dataTableContent">
  			<input type="text" name="CC">
  		</td>
    </tr>
    <tr>
    	<td class="dataTableContent">
  			IP Address: 
  		</td>
    	<td class="dataTableContent">
  			<input type="text" name="ipAddress" value="<?php echo $_SERVER['REMOTE_ADDR']; ?>">
  		</td>
    </tr>
	<tr>
    	<td class="dataTableContent">
  			Request Type: 
  		</td>
        <td class="dataTableContent">
 			<input type="radio" name="requestedType" id="requestedType" value="standard">Standard<br />
        	<input type="radio" name="requestedType" id="requestedType" value="premium">Premium<br />
  		</td>
    </tr>
    <tr>
    	<td class="dataTableContent">
  			Transaction Type: 
  		</td>
    	<td class="dataTableContent">
            <input type="radio" name="transactionType" id="transactionType" value="creditcard">Credit Card<br />
            <input type="radio" name="transactionType" id="transactionType" value="debitcard">Debit Card<br />
            <input type="radio" name="transactionType" id="transactionType" value="paypal">PayPal<br />
            <input type="radio" name="transactionType" id="transactionType" value="google">Google<br />
            <input type="radio" name="transactionType" id="transactionType" value="other">Other<br />
  		</td>
    </tr>
  	<tr>
  		<td colspan="2" class="dataTableContent">
  			<input type="submit" value="Submit">
		</td>
	</tr>
	</form>
</table>

<?php
  require(DIR_WS_INCLUDES . 'template_bottom.php');
  require(DIR_WS_INCLUDES . 'application_bottom.php');
?>